**To create labels**

This example creates a series of labels for a document.

Command::

  aws workdocs create-labels --resource-id d90d93c1fe44bad0c8471e973ebaab339090401a95e777cffa58e977d2983b65 --labels "documents" "examples" "my_documents"

Output::

  None